
import { ScrapRecord } from './types';

export const removeAccents = (str: string): string => {
  return str
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/g, 'd')
    .replace(/Đ/g, 'D');
};

export const fuzzyMatch = (text: string, query: string): boolean => {
  const normalizedText = removeAccents(text).toLowerCase();
  const normalizedQuery = removeAccents(query).toLowerCase();
  return normalizedText.includes(normalizedQuery);
};

export const formatDate = (date: Date): string => {
  return date.toISOString().split('T')[0];
};

export const formatDisplayDate = (dateStr: string): string => {
  if (!dateStr) return '';
  const [year, month, day] = dateStr.split('-');
  return `${day}/${month}/${year.slice(-2)}`;
};

export const formatTime = (timestamp: number): string => {
  return new Date(timestamp).toLocaleTimeString('vi-VN', {
    hour: '2-digit',
    minute: '2-digit'
  });
};

export const getMonthYear = (dateStr: string): string => {
  if (!dateStr) return '';
  const [year, month] = dateStr.split('-');
  return `${month}-${year}`;
};

export const convertRecordsToExport = (records: ScrapRecord[], separator: string = ','): string => {
  if (records.length === 0) return '';
  
  const headers = ['Ngày', 'Mã NV', 'Họ Tên', 'Khối lượng', 'Đơn vị', 'Thời gian', 'Người nhập'];
  const rows = records.map(r => [
    formatDisplayDate(r.date),
    r.employeeCode,
    r.employeeName,
    r.weight.toString(),
    r.unit,
    formatTime(r.timestamp),
    r.createdBy
  ]);

  return [headers, ...rows]
    .map(row => row.map(cell => `"${cell.replace(/"/g, '""')}"`).join(separator))
    .join('\n');
};
