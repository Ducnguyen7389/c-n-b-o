
import React, { useMemo, useState } from 'react';
import { ScrapRecord } from '../types';
import { formatTime, formatDate, formatDisplayDate } from '../utils';

interface HistoryScreenProps {
  records: ScrapRecord[];
  onDelete: (id: string) => void;
}

const HistoryScreen: React.FC<HistoryScreenProps> = ({ records, onDelete }) => {
  const [filterDate, setFilterDate] = useState(formatDate(new Date()));
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [recordToDelete, setRecordToDelete] = useState<ScrapRecord | null>(null);
  
  const filteredRecords = useMemo(() => {
    return records
        .filter(r => r.date === filterDate)
        .sort((a, b) => b.timestamp - a.timestamp);
  }, [records, filterDate]);

  const totalWeight = useMemo(() => {
    return filteredRecords.reduce((sum, r) => sum + r.weight, 0);
  }, [filteredRecords]);

  const handleDeleteRequest = (record: ScrapRecord) => {
    if (record.isLocked) {
      alert("Bản ghi này đã bị khóa, không thể xóa!");
      return;
    }
    setRecordToDelete(record);
    setIsDeleteModalOpen(true);
  };

  const confirmDelete = () => {
    if (recordToDelete) {
      onDelete(recordToDelete.id);
      setIsDeleteModalOpen(false);
      setRecordToDelete(null);
    }
  };

  return (
    <div className="flex flex-col h-full bg-gray-50">
      {/* Date Picker Header - CUSTOM FRAME */}
      <div className="p-4 bg-white flex justify-between items-center border-b border-gray-200 sticky top-0 z-10 shadow-sm">
        <div className="flex-1">
          <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest block mb-1">Ngày xem</label>
          <div className="relative max-w-[160px]">
            <div className="bg-emerald-50 text-emerald-700 font-black border-2 border-emerald-100 rounded-lg px-3 py-2 text-sm flex items-center justify-between">
              <span>{formatDisplayDate(filterDate)}</span>
              <i className="fas fa-caret-down ml-2 opacity-50"></i>
            </div>
            <input 
              type="date" 
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              value={filterDate}
              onChange={(e) => setFilterDate(e.target.value)}
            />
          </div>
        </div>
        <div className="text-right ml-4">
          <div className="text-2xl font-black text-emerald-700 leading-none">{totalWeight.toFixed(1)} <span className="text-xs font-bold uppercase">kg</span></div>
          <div className="text-[10px] font-bold text-gray-400 uppercase tracking-tighter mt-1">Tổng trong ngày</div>
        </div>
      </div>

      {/* Records List */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3 pb-20">
        {filteredRecords.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-24 text-gray-300">
            <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                <i className="fas fa-clipboard-list text-4xl text-gray-200"></i>
            </div>
            <p className="font-bold text-gray-400">Không có bản ghi nào</p>
            <p className="text-xs text-gray-400">Ngày {formatDisplayDate(filterDate)}</p>
          </div>
        ) : (
          filteredRecords.map(record => (
            <div key={record.id} className="bg-white border border-gray-100 rounded-2xl p-4 flex justify-between items-center shadow-sm active:bg-gray-50 transition-colors">
              <div className="flex items-center space-x-3 overflow-hidden">
                <div className="bg-emerald-100 text-emerald-700 w-10 h-10 rounded-full flex items-center justify-center font-black text-sm flex-shrink-0">
                  {record.employeeName.split(' ').pop()?.charAt(0)}
                </div>
                <div className="min-w-0">
                  <div className="font-bold text-gray-800 leading-tight truncate">{record.employeeName}</div>
                  <div className="text-[10px] text-gray-400 flex items-center mt-0.5">
                    <span className="font-mono bg-gray-100 px-1 rounded mr-2 flex-shrink-0">{record.employeeCode}</span>
                    <i className="far fa-clock mr-1 opacity-60"></i>
                    <span>{formatTime(record.timestamp)}</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center space-x-2 flex-shrink-0">
                <div className="text-right mr-1">
                  <div className="font-black text-xl text-gray-800">
                    {record.weight.toFixed(1)} <span className="text-[10px] font-bold text-gray-400 uppercase">kg</span>
                  </div>
                  <div className="flex justify-end space-x-1 mt-1">
                      {record.isLocked && (
                          <span className="text-[7px] bg-red-100 text-red-600 px-1 py-0.5 rounded-sm uppercase font-black">Khóa</span>
                      )}
                      {!record.isSynced && (
                          <span className="text-[7px] bg-orange-100 text-orange-600 px-1 py-0.5 rounded-sm uppercase font-black">Chưa đẩy</span>
                      )}
                  </div>
                </div>
                {!record.isLocked && (
                  <button 
                    onClick={() => handleDeleteRequest(record)}
                    className="w-10 h-10 flex items-center justify-center text-gray-300 hover:text-red-500 active:bg-red-50 rounded-full transition-colors"
                  >
                    <i className="fas fa-trash-alt text-lg"></i>
                  </button>
                )}
              </div>
            </div>
          ))
        )}
      </div>

      {/* Modal: Confirm Delete Record */}
      {isDeleteModalOpen && (
        <div className="fixed inset-0 bg-black/60 z-[60] flex items-center justify-center p-6">
          <div className="bg-white w-full max-w-sm rounded-3xl p-6 shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="w-16 h-16 bg-red-100 text-red-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="fas fa-exclamation-circle text-2xl"></i>
            </div>
            <h3 className="text-xl font-black text-center text-gray-800 mb-2">Xác nhận xóa?</h3>
            <p className="text-center text-gray-500 mb-8 leading-relaxed text-sm">
              Bạn có chắc chắn muốn xóa bản ghi cân mủ của <span className="font-bold text-gray-800">{recordToDelete?.employeeName}</span> ({recordToDelete?.weight}kg)?
            </p>
            <div className="flex space-x-3">
              <button 
                onClick={() => setIsDeleteModalOpen(false)}
                className="flex-1 py-4 font-bold text-gray-500 bg-gray-100 rounded-2xl active:bg-gray-200 transition-colors"
              >
                HỦY
              </button>
              <button 
                onClick={confirmDelete}
                className="flex-1 py-4 bg-red-500 text-white font-black rounded-2xl shadow-lg shadow-red-200 active:scale-95 transition-all uppercase"
              >
                XÓA NGAY
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default HistoryScreen;
