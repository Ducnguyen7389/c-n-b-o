
import React, { useState, useMemo } from 'react';
import { Employee } from '../types';
import { fuzzyMatch } from '../utils';

interface EmployeeScreenProps {
  employees: Employee[];
  onAdd: (name: string, code: string) => void;
  onUpdate: (id: string, name: string, code: string) => void;
  onDelete: (id: string) => void;
}

const EmployeeScreen: React.FC<EmployeeScreenProps> = ({ employees, onAdd, onUpdate, onDelete }) => {
  const [search, setSearch] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [deletingEmployee, setDeletingEmployee] = useState<Employee | null>(null);
  const [formData, setFormData] = useState({ name: '', code: '' });

  const filteredEmployees = useMemo(() => {
    return employees.filter(emp => 
      fuzzyMatch(emp.name, search) || fuzzyMatch(emp.code, search)
    ).sort((a, b) => a.name.localeCompare(b.name));
  }, [employees, search]);

  const openAddModal = () => {
    setEditingId(null);
    setFormData({ 
      name: '', 
      code: `NV${(employees.length + 1).toString().padStart(3, '0')}` 
    });
    setIsModalOpen(true);
  };

  const openEditModal = (emp: Employee) => {
    setEditingId(emp.id);
    setFormData({ name: emp.name, code: emp.code });
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.code.trim()) return;

    if (editingId) {
      onUpdate(editingId, formData.name, formData.code);
    } else {
      onAdd(formData.name, formData.code);
    }
    setIsModalOpen(false);
  };

  const confirmDelete = (emp: Employee) => {
    setDeletingEmployee(emp);
    setIsDeleteModalOpen(true);
  };

  const executeDelete = () => {
    if (deletingEmployee) {
      onDelete(deletingEmployee.id);
      setIsDeleteModalOpen(false);
      setDeletingEmployee(null);
    }
  };

  return (
    <div className="flex flex-col h-full bg-gray-50">
      {/* Header & Search */}
      <div className="p-4 bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-gray-800">Nhân viên ({employees.length})</h2>
          <button 
            onClick={openAddModal}
            className="bg-emerald-600 text-white px-4 py-2 rounded-lg font-bold flex items-center space-x-2 active:scale-95 transition-transform shadow-sm"
          >
            <i className="fas fa-plus"></i>
            <span>Thêm mới</span>
          </button>
        </div>
        <div className="relative">
          <i className="fas fa-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"></i>
          <input 
            type="text" 
            placeholder="Tìm theo tên hoặc mã..." 
            className="w-full pl-10 pr-4 py-3 bg-gray-100 border-0 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </div>

      {/* Employee List */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3 pb-24">
        {filteredEmployees.length === 0 ? (
          <div className="text-center py-20 text-gray-400 italic">
            <i className="fas fa-users-slash text-4xl mb-3 block"></i>
            Không tìm thấy nhân viên nào
          </div>
        ) : (
          filteredEmployees.map(emp => (
            <div key={emp.id} className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 flex justify-between items-center active:bg-gray-50 transition-colors">
              <div className="flex-1">
                <div className="font-bold text-gray-800 text-lg">{emp.name}</div>
                <div className="text-sm text-emerald-600 font-mono font-bold tracking-wider">{emp.code}</div>
              </div>
              <div className="flex items-center space-x-1">
                <button 
                  onClick={() => openEditModal(emp)}
                  className="p-3 text-gray-400 hover:text-emerald-600 active:bg-emerald-50 rounded-full transition-colors"
                  aria-label="Sửa"
                >
                  <i className="fas fa-edit text-xl"></i>
                </button>
                <button 
                  onClick={() => confirmDelete(emp)}
                  className="p-3 text-gray-400 hover:text-red-500 active:bg-red-50 rounded-full transition-colors"
                  aria-label="Xóa"
                >
                  <i className="fas fa-trash-alt text-xl"></i>
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Modal: Add/Edit */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div 
            className="bg-white w-full sm:w-96 rounded-t-3xl sm:rounded-2xl p-6 animate-in slide-in-from-bottom-full duration-300 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-12 h-1.5 bg-gray-200 rounded-full mx-auto mb-6 sm:hidden"></div>
            <h3 className="text-2xl font-black mb-6 text-gray-800">
              {editingId ? 'Sửa thông tin' : 'Thêm nhân viên'}
            </h3>
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="space-y-1">
                <label className="text-xs font-black text-gray-400 uppercase tracking-widest">Họ và Tên</label>
                <input 
                  autoFocus
                  type="text" 
                  required
                  placeholder="Ví dụ: Nguyễn Văn A"
                  className="w-full p-4 bg-gray-50 border-2 border-gray-100 rounded-xl outline-none focus:border-emerald-500 focus:bg-white transition-all text-lg font-bold"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-black text-gray-400 uppercase tracking-widest">Mã Nhân viên</label>
                <input 
                  type="text" 
                  required
                  placeholder="Ví dụ: NV001"
                  className="w-full p-4 bg-gray-50 border-2 border-gray-100 rounded-xl outline-none focus:border-emerald-500 focus:bg-white transition-all text-lg font-mono font-bold"
                  value={formData.code}
                  onChange={(e) => setFormData({...formData, code: e.target.value})}
                />
              </div>
              <div className="flex space-x-3 pt-6">
                <button 
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="flex-1 py-4 font-bold text-gray-500 active:bg-gray-100 rounded-xl transition-colors"
                >
                  HỦY
                </button>
                <button 
                  type="submit"
                  className="flex-[2] py-4 bg-emerald-600 text-white font-black rounded-xl shadow-lg active:scale-95 transition-all uppercase tracking-widest"
                >
                  {editingId ? 'CẬP NHẬT' : 'THÊM MỚI'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Confirm Delete */}
      {isDeleteModalOpen && (
        <div className="fixed inset-0 bg-black/60 z-[60] flex items-center justify-center p-6">
          <div className="bg-white w-full max-w-sm rounded-3xl p-6 shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="w-16 h-16 bg-red-100 text-red-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="fas fa-exclamation-triangle text-2xl"></i>
            </div>
            <h3 className="text-xl font-black text-center text-gray-800 mb-2">Xác nhận xóa?</h3>
            <p className="text-center text-gray-500 mb-8 leading-relaxed">
              Bạn có chắc chắn muốn xóa nhân viên <span className="font-bold text-gray-800">{deletingEmployee?.name}</span>? Thao tác này không thể hoàn tác.
            </p>
            <div className="flex space-x-3">
              <button 
                onClick={() => setIsDeleteModalOpen(false)}
                className="flex-1 py-4 font-bold text-gray-500 bg-gray-100 rounded-2xl active:bg-gray-200 transition-colors"
              >
                HỦY
              </button>
              <button 
                onClick={executeDelete}
                className="flex-1 py-4 bg-red-500 text-white font-black rounded-2xl shadow-lg shadow-red-200 active:scale-95 transition-all uppercase"
              >
                XÓA NGAY
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default EmployeeScreen;
