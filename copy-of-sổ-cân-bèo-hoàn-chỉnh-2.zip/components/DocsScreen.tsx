
import React, { useState, useEffect } from 'react';

const DocsScreen: React.FC = () => {
  const [copied, setCopied] = useState(false);
  const [currentUrl, setCurrentUrl] = useState('');

  useEffect(() => {
    setCurrentUrl(window.location.href);
  }, []);

  const advancedAppsScript = `function doGet(e) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheets = ss.getSheets();
  var allData = [];
  
  sheets.forEach(function(sheet) {
    if (sheet.getName().indexOf("Tháng") === 0) {
      var data = sheet.getDataRange().getValues();
      if (data.length <= 1) return;
      
      var headers = data[0];
      // Tìm vị trí cột ID bản ghi (luôn là cột cuối cùng)
      var idColIdx = headers.length - 1; 
      
      for (var i = 1; i < data.length; i++) {
        var row = data[i];
        if (!row[idColIdx]) continue;
        
        var dateVal = row[0];
        var dateStr = "";
        if (dateVal instanceof Date) {
           dateStr = dateVal.getFullYear() + "-" + ("0" + (dateVal.getMonth() + 1)).slice(-2) + "-" + ("0" + dateVal.getDate()).slice(-2);
        } else {
           dateStr = String(dateVal);
        }

        // Tương thích ngược: Nếu bảng cũ chỉ có 8 cột, các chỉ số sẽ khác
        var isNewFormat = headers.length >= 9;
        
        allData.push({
          date: dateStr,
          employeeId: isNewFormat ? String(row[1]) : String(row[1]), // ID nhân viên
          employeeCode: isNewFormat ? String(row[2]) : String(row[1]), // Mã nhân viên
          employeeName: isNewFormat ? String(row[3]) : String(row[2]), // Tên nhân viên
          weight: isNewFormat ? parseFloat(row[4]) : parseFloat(row[3]),
          unit: isNewFormat ? String(row[5]) : String(row[4]),
          timestamp: isNewFormat ? new Date(row[6]).getTime() : new Date(row[5]).getTime(),
          createdBy: isNewFormat ? String(row[7]) : String(row[6]),
          id: String(row[idColIdx]),
          isSynced: true,
          isLocked: false
        });
      }
    }
  });
  
  return ContentService.createTextOutput(JSON.stringify(allData))
    .setMimeType(ContentService.MimeType.JSON);
}

function doPost(e) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var data = JSON.parse(e.postData.contents);
  
  data.forEach(function(record) {
    var dateParts = record.date.split('-'); 
    var sheetName = "Tháng " + dateParts[1] + "-" + dateParts[0];
    
    var sheet = ss.getSheetByName(sheetName);
    if (!sheet) {
      sheet = ss.insertSheet(sheetName);
      sheet.appendRow(["Ngày", "ID Nhân viên", "Mã NV", "Họ Tên", "Khối lượng", "Đơn vị", "Thời gian nhập", "Người nhập", "ID Bản ghi"]);
      sheet.getRange("A1:I1").setFontWeight("bold").setBackground("#E8F5E9");
      sheet.setFrozenRows(1);
    }
    
    var headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
    var idColIdx = headers.length; // Cột cuối cùng
    
    var ids = sheet.getRange(1, idColIdx, sheet.getLastRow(), 1).getValues().flat();
    if (ids.indexOf(record.id) === -1) {
      // Nếu là sheet cũ (8 cột), ta sẽ chèn theo kiểu cũ để không lỗi, 
      // hoặc tốt nhất là tự động thêm cột nếu thiếu
      if (headers.length === 8) {
         sheet.getRange(1, 2).insertCheckboxes; // Chỉ là ví dụ, thực tế ta nên cập nhật header
         sheet.getRange("A1:I1").setValues([["Ngày", "ID Nhân viên", "Mã NV", "Họ Tên", "Khối lượng", "Đơn vị", "Thời gian nhập", "Người nhập", "ID Bản ghi"]]);
      }
      
      sheet.appendRow([
        record.date,
        record.employeeId,
        record.employeeCode,
        record.employeeName,
        record.weight,
        record.unit,
        new Date(record.timestamp).toLocaleString('vi-VN'),
        record.createdBy,
        record.id
      ]);
    }
  });
  
  return ContentService.createTextOutput("Success");
}`;

  return (
    <div className="p-6 overflow-y-auto h-full space-y-8 pb-32 bg-gray-50">
      <div className="flex bg-gray-200 p-1 rounded-2xl mb-4">
        <div className="flex-1 bg-white text-emerald-700 py-2 rounded-xl text-center text-xs font-black shadow-sm">CẤU HÌNH ĐỒNG BỘ</div>
      </div>

      <section className="text-center space-y-2">
        <div className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center mx-auto text-emerald-600 text-3xl">
          <i className="fas fa-sync-alt"></i>
        </div>
        <h1 className="text-2xl font-black text-gray-800 tracking-tight">CLOUD SYNC V5</h1>
        <p className="text-xs text-gray-500 font-medium px-4 leading-relaxed">Phiên bản "Smart Sync" tự động sửa lỗi lệch cột.</p>
      </section>

      <div className="space-y-4">
        <div className="bg-white rounded-3xl p-5 border border-gray-100 shadow-sm space-y-6">
          <div className="p-4 bg-emerald-50 border border-emerald-100 rounded-2xl">
             <p className="text-[11px] text-emerald-700 leading-relaxed font-medium">
               <i className="fas fa-magic mr-1"></i>
               <b>SỬA LỖI ĐỒNG BỘ:</b> Mã V5 sẽ tự động nhận diện nếu bạn đang dùng bảng cũ hoặc bảng mới. Hãy copy và thay thế ngay.
             </p>
          </div>

          <div className="space-y-3">
            <h4 className="font-bold text-gray-800 text-sm">Bước 1: Copy mã V5</h4>
            <button 
              onClick={() => { navigator.clipboard.writeText(advancedAppsScript); setCopied(true); setTimeout(() => setCopied(false), 2000); }}
              className={`w-full py-4 rounded-2xl font-black text-[11px] uppercase tracking-widest transition-all border-2 flex items-center justify-center space-x-2 ${copied ? 'bg-yellow-400 border-yellow-500 text-yellow-900' : 'bg-emerald-50 border-emerald-100 text-emerald-700'}`}
            >
              <i className={`fas ${copied ? 'fa-check' : 'fa-copy'}`}></i>
              <span>{copied ? 'ĐÃ COPY MÃ V5' : 'COPY MÃ APPS SCRIPT (V5)'}</span>
            </button>
          </div>

          <div className="space-y-3">
            <h4 className="font-bold text-gray-800 text-sm">Bước 2: Cập nhật Apps Script</h4>
            <p className="text-[11px] text-gray-500 leading-relaxed">
              Dán đè mã V5 này vào mục Code.gs trong Apps Script, sau đó <b>Triển khai phiên bản mới</b>.
            </p>
          </div>
        </div>
      </div>

      <div className="text-center pb-4">
         <p className="text-[10px] text-gray-300 font-bold uppercase tracking-[0.2em]">RubberTrack v1.7.0 • Smart Sync V5</p>
      </div>
    </div>
  );
};

export default DocsScreen;
