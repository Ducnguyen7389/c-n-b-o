
import React from 'react';
import { AppScreen } from '../types';

interface LayoutProps {
  children: React.ReactNode;
  activeScreen: AppScreen;
  setScreen: (screen: AppScreen) => void;
  pendingSyncCount: number;
  isOnline: boolean;
  isSyncing?: boolean;
}

const Layout: React.FC<LayoutProps> = ({ children, activeScreen, setScreen, pendingSyncCount, isOnline, isSyncing }) => {
  const isBlob = window.location.href.startsWith('blob:');

  const handleOpenStandalone = () => {
    if (isBlob) {
      alert("Bạn đang ở chế độ Xem trước. Hãy vào phần Hướng dẫn để lấy link cài đặt App chính thức.");
      setScreen(AppScreen.DOCS);
      return;
    }

    try {
      const newWindow = window.open(window.location.href, '_blank');
      if (!newWindow) {
        setScreen(AppScreen.DOCS);
      }
    } catch (e) {
      setScreen(AppScreen.DOCS);
    }
  };

  return (
    <div className="flex flex-col fixed inset-0 bg-white overflow-hidden select-none">
      {/* Banner cảnh báo lưu trữ tạm thời */}
      {isBlob && (
        <div className="bg-red-600 text-white text-[10px] font-bold py-1.5 px-4 text-center animate-pulse">
          <i className="fas fa-exclamation-triangle mr-2"></i>
          CHẾ ĐỘ XEM TRƯỚC: DỮ LIỆU SẼ MẤT KHI THOÁT. HÃY CÀI ĐẶT APP ĐỂ LƯU VĨNH VIỄN!
        </div>
      )}

      {/* Header */}
      <header className="bg-emerald-700 text-white px-4 pt-2 pb-3 flex items-center justify-between shadow-md z-50">
        <div className="flex items-center space-x-2">
          <div className="relative">
            <i className="fas fa-leaf text-xl text-emerald-300"></i>
            {isSyncing && (
              <div className="absolute -top-1 -right-1">
                <i className="fas fa-sync fa-spin text-[8px] text-white"></i>
              </div>
            )}
          </div>
          <div>
            <h1 className="font-black text-sm tracking-tight leading-none uppercase">RubberTrack</h1>
            <div className="flex items-center mt-1">
               <div className={`w-1.5 h-1.5 rounded-full mr-1.5 ${isOnline ? 'bg-emerald-400' : 'bg-red-400'}`}></div>
               <span className="text-[8px] uppercase font-black opacity-80 tracking-widest">{isOnline ? 'Cloud Drive Online' : 'Ngoại tuyến'}</span>
            </div>
          </div>
        </div>
        <div className="flex items-center space-x-1">
            <button 
              onClick={handleOpenStandalone}
              className={`p-2 ${isBlob ? 'text-red-300' : 'text-emerald-200'}`}
              title="Mở App chính thức"
            >
              <i className="fas fa-external-link-alt text-xs"></i>
            </button>

            {pendingSyncCount > 0 && (
                <div className="bg-orange-500 text-white text-[9px] font-black px-1.5 py-0.5 rounded-full mx-1">
                    {pendingSyncCount}
                </div>
            )}
            
            <button onClick={() => setScreen(AppScreen.DOCS)} className="p-2">
                <i className={`fas fa-circle-info ${activeScreen === AppScreen.DOCS ? 'text-emerald-200' : 'text-white'}`}></i>
            </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto relative bg-gray-50 pb-2">
        {children}
      </main>

      {/* Bottom Nav */}
      <nav className="bg-white border-t border-gray-200 flex justify-around items-center py-2 px-1 shadow-[0_-2px_10px_rgba(0,0,0,0.05)]">
        <button onClick={() => setScreen(AppScreen.ENTRY)} className={`flex flex-col items-center flex-1 py-1 ${activeScreen === AppScreen.ENTRY ? 'text-emerald-600' : 'text-gray-400'}`}>
          <i className="fas fa-plus-circle text-xl mb-1"></i>
          <span className="text-[9px] font-black uppercase tracking-tighter">Nhập</span>
        </button>
        <button onClick={() => setScreen(AppScreen.HISTORY)} className={`flex flex-col items-center flex-1 py-1 ${activeScreen === AppScreen.HISTORY ? 'text-emerald-600' : 'text-gray-400'}`}>
          <i className="fas fa-list-ul text-xl mb-1"></i>
          <span className="text-[9px] font-black uppercase tracking-tighter">Lịch sử</span>
        </button>
        <button onClick={() => setScreen(AppScreen.SUMMARY)} className={`flex flex-col items-center flex-1 py-1 ${activeScreen === AppScreen.SUMMARY ? 'text-emerald-600' : 'text-gray-400'}`}>
          <i className="fas fa-chart-pie text-xl mb-1"></i>
          <span className="text-[9px] font-black uppercase tracking-tighter">T.Kết</span>
        </button>
        <button onClick={() => setScreen(AppScreen.EMPLOYEES)} className={`flex flex-col items-center flex-1 py-1 ${activeScreen === AppScreen.EMPLOYEES ? 'text-emerald-600' : 'text-gray-400'}`}>
          <i className="fas fa-users text-xl mb-1"></i>
          <span className="text-[9px] font-black uppercase tracking-tighter">N.Viên</span>
        </button>
        <button onClick={() => setScreen(AppScreen.SYNC)} className={`flex flex-col items-center flex-1 py-1 ${activeScreen === AppScreen.SYNC ? 'text-emerald-600' : 'text-gray-400'}`}>
          <div className="relative">
            <i className={`fas fa-cloud-arrow-up text-xl mb-1 ${isSyncing ? 'animate-bounce text-orange-500' : ''}`}></i>
            {pendingSyncCount > 0 && <span className="absolute -top-1 -right-1 bg-orange-500 w-2 h-2 rounded-full border border-white"></span>}
          </div>
          <span className="text-[9px] font-black uppercase tracking-tighter">D.Bộ</span>
        </button>
      </nav>
      
      <div className="h-[env(safe-area-inset-bottom)] bg-white"></div>
    </div>
  );
};

export default Layout;
