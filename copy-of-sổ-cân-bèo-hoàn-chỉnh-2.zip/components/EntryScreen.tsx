
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Employee, ScrapRecord } from '../types';
import { DEFAULT_UNIT } from '../constants';
import { fuzzyMatch, formatDate, formatDisplayDate } from '../utils';

interface EntryScreenProps {
  employees: Employee[];
  onSave: (record: Omit<ScrapRecord, 'id' | 'timestamp' | 'createdBy' | 'isLocked' | 'isSynced'>) => void;
  isOnline: boolean;
}

const EntryScreen: React.FC<EntryScreenProps> = ({ employees, onSave, isOnline }) => {
  const [selectedDate, setSelectedDate] = useState(formatDate(new Date()));
  const [search, setSearch] = useState('');
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);
  const [weight, setWeight] = useState('');
  const [showSuccess, setShowSuccess] = useState(false);
  
  const searchInputRef = useRef<HTMLInputElement>(null);
  const weightInputRef = useRef<HTMLInputElement>(null);

  const filteredEmployees = useMemo(() => {
    if (!search || selectedEmployee) return [];
    return employees.filter(emp => 
      fuzzyMatch(emp.name, search) || fuzzyMatch(emp.code, search)
    ).slice(0, 5);
  }, [search, selectedEmployee, employees]);

  useEffect(() => {
    searchInputRef.current?.focus();
  }, []);

  const handleSelectEmployee = (emp: Employee) => {
    setSelectedEmployee(emp);
    setSearch(emp.name);
    setTimeout(() => weightInputRef.current?.focus(), 50);
  };

  const handleReset = () => {
    setSelectedEmployee(null);
    setSearch('');
    setWeight('');
    searchInputRef.current?.focus();
  };

  const handleSave = () => {
    if (!selectedEmployee || !weight || parseFloat(weight) <= 0) return;

    onSave({
      employeeId: selectedEmployee.id,
      employeeName: selectedEmployee.name,
      employeeCode: selectedEmployee.code,
      weight: parseFloat(weight),
      unit: DEFAULT_UNIT,
      date: selectedDate,
    });

    setShowSuccess(true);
    setTimeout(() => {
      setShowSuccess(false);
      handleReset();
    }, 1500);
  };

  return (
    <div className="p-4 flex flex-col h-full space-y-5">
      {/* Date Selection - CUSTOM FRAME */}
      <div className="space-y-1.5">
        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest flex items-center">
          <i className="fas fa-calendar-day mr-2 text-emerald-500"></i> Ngày ghi nhận
        </label>
        <div className="relative">
          {/* Lớp hiển thị DD/MM/YY */}
          <div className="w-full p-4 bg-gray-100 border-2 border-emerald-100 rounded-xl flex justify-between items-center">
            <span className="text-xl font-black text-emerald-800 tracking-wider">
              {formatDisplayDate(selectedDate)}
            </span>
            <i className="fas fa-calendar-alt text-emerald-500 text-lg"></i>
          </div>
          {/* Ô input ẩn bên dưới để kích hoạt date picker */}
          <input 
            type="date" 
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
          />
        </div>
      </div>

      <div className="space-y-1.5">
        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest flex items-center">
          <i className="fas fa-user-tag mr-2 text-emerald-500"></i> Nhân viên
        </label>
        <div className="relative">
          <input
            ref={searchInputRef}
            type="text"
            className={`w-full p-4 text-xl font-bold border-2 rounded-xl focus:ring-4 focus:ring-emerald-100 outline-none transition-all ${
              selectedEmployee ? 'bg-emerald-50 border-emerald-500 text-emerald-800' : 'bg-white border-gray-200'
            }`}
            placeholder="Gõ tên hoặc mã..."
            value={search}
            onChange={(e) => {
                setSearch(e.target.value);
                if (selectedEmployee) setSelectedEmployee(null);
            }}
          />
          {selectedEmployee && (
            <button 
              onClick={handleReset}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-red-500 p-2"
            >
              <i className="fas fa-times-circle text-xl"></i>
            </button>
          )}
        </div>

        {!selectedEmployee && filteredEmployees.length > 0 && (
          <div className="bg-white border border-gray-200 rounded-xl shadow-lg overflow-hidden animate-in fade-in slide-in-from-top-2 z-10">
            {filteredEmployees.map((emp) => (
              <button
                key={emp.id}
                onClick={() => handleSelectEmployee(emp)}
                className="w-full text-left px-4 py-3 border-b border-gray-100 last:border-0 active:bg-emerald-50 flex justify-between items-center"
              >
                <div>
                  <div className="font-bold text-gray-800">{emp.name}</div>
                  <div className="text-xs text-gray-500 font-mono">{emp.code}</div>
                </div>
                <i className="fas fa-chevron-right text-emerald-200"></i>
              </button>
            ))}
          </div>
        )}
      </div>

      <div className={`space-y-1.5 transition-opacity duration-300 ${selectedEmployee ? 'opacity-100' : 'opacity-30 pointer-events-none'}`}>
        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest flex items-center">
          <i className="fas fa-weight-hanging mr-2 text-emerald-500"></i> Khối lượng ({DEFAULT_UNIT})
        </label>
        <div className="relative">
          <input
            ref={weightInputRef}
            type="number"
            inputMode="decimal"
            className="w-full p-4 text-5xl font-black border-2 border-gray-200 rounded-2xl focus:border-emerald-500 focus:ring-8 focus:ring-emerald-50 outline-none transition-all text-center"
            placeholder="0.0"
            value={weight}
            onChange={(e) => setWeight(e.target.value)}
            disabled={!selectedEmployee}
          />
          <div className="absolute right-6 top-1/2 -translate-y-1/2 font-black text-gray-300 text-2xl uppercase italic">
            {DEFAULT_UNIT}
          </div>
        </div>
      </div>

      <div className="mt-auto pt-4 flex flex-col space-y-2">
        {!isOnline && (
          <div className="flex items-center justify-center space-x-2 text-[10px] text-orange-600 font-bold bg-orange-50 py-2 rounded-lg border border-orange-100">
            <i className="fas fa-wifi-slash"></i>
            <span>NGOẠI TUYẾN: Dữ liệu sẽ lưu tạm vào máy</span>
          </div>
        )}
        <button
          onClick={handleSave}
          disabled={!selectedEmployee || !weight || parseFloat(weight) <= 0}
          className={`w-full py-5 rounded-2xl text-xl font-black uppercase tracking-widest shadow-xl transform active:scale-95 transition-all flex items-center justify-center space-x-3 ${
            selectedEmployee && weight && parseFloat(weight) > 0
              ? 'bg-emerald-600 text-white shadow-emerald-200'
              : 'bg-gray-200 text-gray-400 cursor-not-allowed shadow-none'
          }`}
        >
          <i className="fas fa-save text-2xl"></i>
          <span>LƯU DỮ LIỆU</span>
        </button>
      </div>

      {showSuccess && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-white/95 animate-in fade-in duration-300">
          <div className="text-center px-6">
            <div className="w-24 h-24 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4 animate-bounce">
              <i className="fas fa-check text-5xl text-emerald-600"></i>
            </div>
            <h2 className="text-3xl font-black text-gray-800">ĐÃ LƯU!</h2>
            <p className="text-gray-500 mt-2 font-medium">Dữ liệu đã được lưu an toàn vào bộ nhớ điện thoại.</p>
            <p className="text-emerald-600 text-[11px] font-black uppercase tracking-widest mt-4">Sẵn sàng nhập tiếp...</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default EntryScreen;
