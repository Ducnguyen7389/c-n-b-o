
import React, { useState, useMemo, useEffect, useRef } from 'react';
import { ScrapRecord } from '../types';
import { formatDisplayDate, convertRecordsToExport } from '../utils';
import { db } from '../db';
// @ts-ignore
import html2canvas from 'https://esm.sh/html2canvas';

interface SummaryScreenProps {
  records: ScrapRecord[];
}

const PRICES_SETTING_KEY = 'rubber_track_monthly_prices_v2';

const SummaryScreen: React.FC<SummaryScreenProps> = ({ records }) => {
  const [selectedMonth, setSelectedMonth] = useState(() => {
    const now = new Date();
    return `${now.getFullYear()}-${(now.getMonth() + 1).toString().padStart(2, '0')}`;
  });
  const [selectedEmpId, setSelectedEmpId] = useState<string | null>(null);
  const [monthlyPrices, setMonthlyPrices] = useState<Record<string, string>>({});
  const [isPriceLoading, setIsPriceLoading] = useState(true);
  const [isCapturing, setIsCapturing] = useState(false);

  const receiptRef = useRef<HTMLDivElement>(null);

  const currentPrice = monthlyPrices[selectedMonth] || '';

  useEffect(() => {
    const loadPrices = async () => {
      const saved = await db.getSetting<Record<string, string>>(PRICES_SETTING_KEY);
      if (saved) setMonthlyPrices(saved);
      setIsPriceLoading(false);
    };
    loadPrices();
  }, []);

  const handlePriceChange = async (val: string) => {
    const newPrices = { ...monthlyPrices, [selectedMonth]: val };
    setMonthlyPrices(newPrices);
    await db.setSetting(PRICES_SETTING_KEY, newPrices);
  };

  const monthRecords = useMemo(() => {
    return records.filter(r => r.date.startsWith(selectedMonth));
  }, [records, selectedMonth]);

  const totalMonthWeight = useMemo(() => {
    return monthRecords.reduce((sum, r) => sum + r.weight, 0);
  }, [monthRecords]);

  const summaryData = useMemo(() => {
    const groups: Record<string, { id: string; name: string; code: string; totalWeight: number; count: number }> = {};
    
    monthRecords.forEach(record => {
      const groupId = record.employeeId || record.employeeCode;
      
      if (!groups[groupId]) {
        groups[groupId] = {
          id: groupId,
          name: record.employeeName,
          code: record.employeeCode,
          totalWeight: 0,
          count: 0
        };
      }
      groups[groupId].totalWeight += record.weight;
      groups[groupId].count += 1;
    });
    
    return Object.values(groups).sort((a, b) => b.totalWeight - a.totalWeight);
  }, [monthRecords]);

  const employeeDetail = useMemo(() => {
    if (!selectedEmpId) return null;
    const empRecords = monthRecords
      .filter(r => (r.employeeId === selectedEmpId || r.employeeCode === selectedEmpId))
      .sort((a, b) => b.date.localeCompare(a.date));
      
    if (empRecords.length === 0) return null;

    const total = empRecords.reduce((sum, r) => sum + r.weight, 0);
    const payoutWeight = total * 0.2;
    const price = parseFloat(currentPrice) || 0;
    const totalMoney = payoutWeight * price;

    return {
      name: empRecords[0].employeeName,
      code: empRecords[0].employeeCode,
      records: empRecords,
      total,
      payoutWeight,
      totalMoney
    };
  }, [selectedEmpId, monthRecords, currentPrice]);

  const handleCaptureReceipt = async () => {
    if (!receiptRef.current) return;
    setIsCapturing(true);

    try {
      const canvas = await html2canvas(receiptRef.current, {
        scale: 2, // Tăng chất lượng ảnh
        useCORS: true,
        backgroundColor: '#f9fafb',
        logging: false,
      });

      canvas.toBlob(async (blob: Blob | null) => {
        if (!blob) return;

        const fileName = `Bien-lai-${employeeDetail?.code}-${selectedMonth}.png`;
        const file = new File([blob], fileName, { type: 'image/png' });

        // Kiểm tra xem trình duyệt có hỗ trợ chia sẻ file không
        if (navigator.share && navigator.canShare && navigator.canShare({ files: [file] })) {
          await navigator.share({
            files: [file],
            title: 'Biên lai mủ bèo',
            text: `Tổng kết mủ bèo tháng ${selectedMonth} - ${employeeDetail?.name}`,
          });
        } else {
          // Nếu không hỗ trợ share, thì tải về máy
          const url = URL.createObjectURL(blob);
          const link = document.createElement('a');
          link.href = url;
          link.download = fileName;
          link.click();
          alert("Đã lưu ảnh vào máy!");
        }
      }, 'image/png');
    } catch (err) {
      console.error("Capture failed", err);
      alert("Không thể chụp ảnh. Vui lòng thử lại.");
    } finally {
      setIsCapturing(false);
    }
  };

  const exportMonthCSV = () => {
    if (monthRecords.length === 0) return;
    const csvContent = "\uFEFF" + convertRecordsToExport(monthRecords, ',');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `bao-cao-mu-beo-${selectedMonth}.csv`);
    link.click();
  };

  if (selectedEmpId && employeeDetail) {
    return (
      <div className="flex flex-col h-full bg-gray-50 animate-in slide-in-from-right duration-300">
        <div className="p-4 bg-white border-b border-gray-200 sticky top-0 z-20 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <button 
                onClick={() => setSelectedEmpId(null)}
                className="w-10 h-10 flex items-center justify-center text-emerald-600 bg-emerald-50 rounded-full active:scale-90 transition-transform"
            >
                <i className="fas fa-arrow-left"></i>
            </button>
            <div>
                <h2 className="font-black text-gray-800 leading-tight uppercase text-sm">{employeeDetail.name}</h2>
                <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">{employeeDetail.code}</p>
            </div>
          </div>
          <button 
            onClick={handleCaptureReceipt}
            disabled={isCapturing}
            className="bg-emerald-600 text-white px-3 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center shadow-lg shadow-emerald-100 active:scale-95 transition-all"
          >
            {isCapturing ? <i className="fas fa-spinner fa-spin mr-1"></i> : <i className="fas fa-camera mr-1"></i>}
            {isCapturing ? 'Đang chụp...' : 'Chụp & Gửi'}
          </button>
        </div>

        <div className="p-4 space-y-4 pb-24">
          {/* Vùng chụp ảnh BIÊN LAI */}
          <div ref={receiptRef} className="bg-gray-50 p-2 rounded-[2.5rem]">
            <div className="bg-white rounded-[2rem] shadow-xl border border-gray-100 overflow-hidden">
                {/* Header Biên lai cho sếp xem */}
                <div className="p-4 bg-gray-50 border-b border-gray-100 flex justify-between items-center">
                    <div className="flex items-center space-x-2">
                        <i className="fas fa-leaf text-emerald-600"></i>
                        <span className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">RubberTrack Receipt</span>
                    </div>
                    <div className="text-[9px] font-bold text-gray-400 uppercase">
                        {new Date().toLocaleDateString('vi-VN')} {new Date().toLocaleTimeString('vi-VN', {hour:'2-digit', minute:'2-digit'})}
                    </div>
                </div>

                <div className="bg-emerald-700 p-8 text-white text-center relative overflow-hidden">
                    {/* Họa tiết trang trí */}
                    <div className="absolute -top-10 -right-10 w-32 h-32 bg-white/10 rounded-full blur-2xl"></div>
                    <div className="absolute -bottom-10 -left-10 w-32 h-32 bg-emerald-400/20 rounded-full blur-2xl"></div>
                    
                    <div className="relative z-10">
                        <div className="text-[10px] uppercase font-black opacity-60 tracking-[0.2em] mb-2">Thực nhận (20%)</div>
                        <div className="text-6xl font-black mb-1 drop-shadow-md">{employeeDetail.payoutWeight.toFixed(1)} <span className="text-xl">kg</span></div>
                        <div className="h-px bg-white/20 w-16 mx-auto my-5"></div>
                        <div className="text-[10px] uppercase font-black opacity-60 tracking-[0.2em] mb-2">Thành tiền tạm tính</div>
                        <div className="text-4xl font-black text-emerald-200 drop-shadow-sm">
                            {employeeDetail.totalMoney.toLocaleString('vi-VN')} <span className="text-xs uppercase opacity-70 tracking-normal">đ</span>
                        </div>
                    </div>
                </div>

                <div className="p-6 space-y-6">
                    <div className="grid grid-cols-2 gap-4">
                        <div className="p-4 bg-emerald-50/50 rounded-2xl border border-emerald-50">
                            <div className="text-[9px] font-black text-emerald-600/60 uppercase mb-1">Công nhân</div>
                            <div className="font-black text-emerald-900 uppercase text-xs truncate">{employeeDetail.name}</div>
                            <div className="text-[9px] font-bold text-emerald-600/40 uppercase">{employeeDetail.code}</div>
                        </div>
                        <div className="p-4 bg-emerald-50/50 rounded-2xl border border-emerald-50">
                            <div className="text-[9px] font-black text-emerald-600/60 uppercase mb-1">Kỳ báo cáo</div>
                            <div className="font-black text-emerald-900 text-xs">Tháng {selectedMonth.split('-').reverse().join('/')}</div>
                            <div className="text-[9px] font-bold text-emerald-600/40 uppercase">RubberTrack App</div>
                        </div>
                    </div>

                    <div className="space-y-3">
                        <div className="flex justify-between items-center text-[10px] font-black text-gray-300 uppercase tracking-widest px-2">
                            <span>Chi tiết cân mủ</span>
                            <span>{employeeDetail.records.length} Lượt</span>
                        </div>
                        <div className="bg-gray-50 rounded-2xl overflow-hidden divide-y divide-white">
                            {employeeDetail.records.slice(0, 10).map((r) => (
                                <div key={r.id} className="p-3 flex justify-between items-center">
                                    <span className="text-[10px] font-black text-gray-500">{formatDisplayDate(r.date)}</span>
                                    <span className="text-xs font-black text-gray-800">{r.weight.toFixed(1)} kg</span>
                                </div>
                            ))}
                            {employeeDetail.records.length > 10 && (
                                <div className="p-2 text-center text-[9px] font-bold text-gray-300 italic">
                                    ... và {employeeDetail.records.length - 10} lượt cân khác
                                </div>
                            )}
                        </div>
                    </div>

                    <div className="pt-4 border-t border-dashed border-gray-200 flex justify-between items-center">
                        <div>
                            <div className="text-[9px] font-black text-gray-400 uppercase">Tổng mủ bèo</div>
                            <div className="font-black text-gray-800">{employeeDetail.total.toFixed(1)} kg</div>
                        </div>
                        <div className="text-right">
                            <div className="text-[9px] font-black text-gray-400 uppercase">Đơn giá</div>
                            <div className="font-black text-gray-800">{parseFloat(currentPrice || '0').toLocaleString('vi-VN')} đ/kg</div>
                        </div>
                    </div>
                </div>
                
                {/* Footer ảnh chụp */}
                <div className="bg-gray-100 p-4 text-center">
                    <p className="text-[8px] font-black text-gray-400 uppercase tracking-[0.3em]">Xác nhận bởi Quản lý Hiện trường</p>
                </div>
            </div>
          </div>

          <div className="p-4 bg-orange-50 border border-orange-100 rounded-2xl">
              <p className="text-[10px] text-orange-700 leading-relaxed font-medium">
                <i className="fas fa-info-circle mr-1"></i>
                Bấm nút <b>"Chụp & Gửi"</b> góc trên để xuất hình ảnh biên lai đẹp mắt, gửi nhanh qua Zalo cho Sếp hoặc Công nhân.
              </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-gray-50">
      <div className="p-4 bg-white border-b border-gray-200 sticky top-0 z-10 shadow-sm space-y-4">
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-black text-gray-800 uppercase tracking-tighter italic">Tổng kết tháng</h2>
          <div className="flex space-x-2">
            <button 
                onClick={exportMonthCSV} 
                className="bg-gray-100 text-gray-600 w-10 h-10 rounded-xl active:bg-blue-100 active:text-blue-600 flex items-center justify-center transition-colors shadow-inner"
            >
              <i className="fas fa-download"></i>
            </button>
            <div className="relative">
              <div className="bg-emerald-700 text-white font-black rounded-xl px-4 py-2 text-xs flex items-center shadow-lg shadow-emerald-100">
                <span>{selectedMonth.split('-').reverse().join('/')}</span>
                <i className="fas fa-calendar-day ml-2 opacity-50"></i>
              </div>
              <input 
                type="month" 
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(e.target.value)}
              />
            </div>
          </div>
        </div>

        <div className="bg-emerald-50 rounded-2xl p-4 border border-emerald-100 flex items-center justify-between">
            <div>
                <div className="text-[10px] font-black text-emerald-600 uppercase tracking-widest">Tổng mủ cả tháng</div>
                <div className="text-2xl font-black text-emerald-900">{totalMonthWeight.toFixed(1)} <span className="text-xs uppercase">kg</span></div>
            </div>
            <div className="text-right">
                <div className="text-[10px] font-black text-emerald-600 uppercase tracking-widest">Số lượt cân</div>
                <div className="text-2xl font-black text-emerald-900">{monthRecords.length} <span className="text-xs uppercase">lượt</span></div>
            </div>
        </div>

        <div className="relative">
          <div className="absolute left-4 top-1/2 -translate-y-1/2 text-emerald-600 font-black text-[10px] uppercase">Giá chi trả:</div>
          <input 
            type="number" 
            inputMode="numeric"
            placeholder={isPriceLoading ? "..." : "0"}
            className="w-full pl-24 pr-16 py-4 bg-gray-50 border-2 border-transparent focus:border-emerald-500 rounded-2xl outline-none font-black text-emerald-800 text-lg transition-all"
            value={currentPrice}
            onChange={(e) => handlePriceChange(e.target.value)}
            disabled={isPriceLoading}
          />
          <div className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-300 font-black text-[10px] uppercase italic">VNĐ/KG</div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-3 pb-24">
        <div className="flex items-center justify-between px-3 text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">
          <span>Công nhân</span>
          <div className="flex space-x-12">
            <span className="w-12 text-right">Tổng mủ</span>
            <span className="w-16 text-right text-emerald-600">Thực nhận</span>
          </div>
        </div>
        
        {summaryData.length === 0 ? (
          <div className="text-center py-24 text-gray-300">
            <i className="fas fa-layer-group text-5xl mb-4 opacity-20"></i>
            <p className="font-black uppercase text-xs tracking-widest">Chưa có dữ liệu tháng này</p>
          </div>
        ) : (
          summaryData.map(item => {
            const payout = item.totalWeight * 0.2;
            return (
              <button 
                key={item.id} 
                onClick={() => setSelectedEmpId(item.id)}
                className="w-full bg-white p-4 rounded-[1.5rem] shadow-sm border border-gray-100 flex justify-between items-center active:scale-[0.97] transition-all text-left"
              >
                <div className="flex-1 min-w-0 pr-2">
                  <div className="font-black text-gray-800 truncate uppercase text-sm">{item.name}</div>
                  <div className="text-[10px] text-gray-400 font-bold flex items-center tracking-tighter">
                    {item.code} 
                    <span className="mx-2 opacity-30">•</span> 
                    {item.count} lượt cân
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="text-right w-16">
                    <div className="text-sm font-bold text-gray-400">{item.totalWeight.toFixed(1)}</div>
                  </div>
                  <div className="text-right w-20">
                    <div className="text-lg font-black text-emerald-700">{payout.toFixed(1)}</div>
                    <div className="text-[8px] text-emerald-500 font-black uppercase tracking-tighter -mt-1">KG nhận</div>
                  </div>
                  <i className="fas fa-chevron-right text-gray-200 text-[10px] ml-1"></i>
                </div>
              </button>
            );
          })
        )}
      </div>
    </div>
  );
};

export default SummaryScreen;
