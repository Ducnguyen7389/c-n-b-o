
export interface Employee {
  id: string;
  code: string;
  name: string;
}

export interface ScrapRecord {
  id: string;
  employeeId: string;
  employeeName: string;
  employeeCode: string;
  weight: number;
  unit: string;
  timestamp: number;
  date: string; // YYYY-MM-DD
  createdBy: string;
  isLocked: boolean;
  isSynced: boolean;
}

export enum AppScreen {
  ENTRY = 'ENTRY',
  HISTORY = 'HISTORY',
  EMPLOYEES = 'EMPLOYEES',
  SUMMARY = 'SUMMARY',
  SYNC = 'SYNC',
  DOCS = 'DOCS'
}
