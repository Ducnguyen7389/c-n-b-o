
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { AppScreen, ScrapRecord, Employee } from './types';
import Layout from './components/Layout';
import EntryScreen from './components/EntryScreen';
import HistoryScreen from './components/HistoryScreen';
import EmployeeScreen from './components/EmployeeScreen';
import SummaryScreen from './components/SummaryScreen';
import DocsScreen from './components/DocsScreen';
import { formatDate, convertRecordsToExport } from './utils';
import { CURRENT_USER, MOCK_EMPLOYEES } from './constants';
import { db, STORES } from './db';

const WEBHOOK_URL_KEY = 'rubber_track_webhook_url';
const AUTO_SYNC_KEY = 'rubber_track_auto_sync';

const generateId = () => {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    return crypto.randomUUID();
  }
  return Math.random().toString(36).substring(2, 15) + Date.now().toString(36);
};

const App: React.FC = () => {
  const [activeScreen, setActiveScreen] = useState<AppScreen>(AppScreen.ENTRY);
  const [records, setRecords] = useState<ScrapRecord[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [isSyncing, setIsSyncing] = useState(false);
  const [webhookUrl, setWebhookUrl] = useState('');
  const [autoSync, setAutoSync] = useState(true);
  const [isInitializing, setIsInitializing] = useState(true);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  
  const webhookUrlRef = useRef('');

  const pullFromCloud = useCallback(async (silent = false) => {
    const url = webhookUrlRef.current;
    if (!url || !navigator.onLine) return;

    if (!silent) setIsSyncing(true);
    try {
      // Thêm timestamp để tránh cache trình duyệt
      const response = await fetch(`${url}?t=${Date.now()}`);
      if (!response.ok) {
        throw new Error("Không thể kết nối Cloud");
      }
      
      const text = await response.text();
      let cloudRecords: any[];
      try {
        cloudRecords = JSON.parse(text);
      } catch (e) {
        throw new Error("Dữ liệu không hợp lệ");
      }
      
      if (Array.isArray(cloudRecords)) {
        const currentLocal = await db.getAll<ScrapRecord>(STORES.RECORDS);
        const localIds = new Set(currentLocal.map(r => r.id));
        let hasNew = false;

        for (const record of cloudRecords) {
          if (!record.id) continue;
          
          if (!localIds.has(record.id)) {
            if (record.date && record.date.includes('T')) {
                record.date = record.date.split('T')[0];
            }
            await db.put(STORES.RECORDS, {
                ...record,
                isSynced: true
            });
            hasNew = true;
          }
        }

        if (hasNew || !silent) {
          const updated = await db.getAll<ScrapRecord>(STORES.RECORDS);
          setRecords(updated.sort((a, b) => b.timestamp - a.timestamp));
        }
      }
    } catch (e) {
      console.warn("Pull failed", e);
      if (!silent) alert("Lỗi tải dữ liệu: Vui lòng kiểm tra lại Link và quyền truy cập 'Anyone' trong Apps Script.");
    } finally {
      if (!silent) setIsSyncing(false);
    }
  }, []);

  const pushToCloud = useCallback(async (manualRecords?: ScrapRecord[]) => {
    const url = webhookUrlRef.current;
    if (!url || !navigator.onLine) return;

    setIsSyncing(true);
    const currentRecords = await db.getAll<ScrapRecord>(STORES.RECORDS);
    const toSync = manualRecords || currentRecords.filter(r => !r.isSynced);
    
    if (toSync.length === 0) {
      setIsSyncing(false);
      return;
    }

    try {
      // Chuyển sang dùng fetch với mode cors nếu có thể, hoặc giữ no-cors nhưng xử lý khéo léo
      await fetch(url, {
        method: 'POST',
        mode: 'no-cors',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(toSync)
      });
      
      // Với no-cors ta không biết chắc thành công, nhưng ta đánh dấu local là đã sync
      // để tránh gửi lại liên tục.
      for (const record of toSync) {
        await db.put(STORES.RECORDS, { ...record, isSynced: true });
      }
      
      const updated = await db.getAll<ScrapRecord>(STORES.RECORDS);
      setRecords(updated.sort((a, b) => b.timestamp - a.timestamp));
    } catch (e) {
      console.warn("Push failed", e);
    } finally {
      setIsSyncing(false);
    }
  }, []);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    const handleFocus = () => pullFromCloud(true);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    window.addEventListener('focus', handleFocus);
    
    const initData = async () => {
      try {
        const cachedWebhook = localStorage.getItem(WEBHOOK_URL_KEY) || "";
        const cachedAutoSync = localStorage.getItem(AUTO_SYNC_KEY) === 'false' ? false : true;

        const [savedRecords, savedEmployees, savedWebhook, savedAutoSync] = await Promise.all([
          db.getAll<ScrapRecord>(STORES.RECORDS),
          db.getAll<Employee>(STORES.EMPLOYEES),
          db.getSetting<string>(WEBHOOK_URL_KEY),
          db.getSetting<boolean>(AUTO_SYNC_KEY)
        ]);

        if (savedEmployees.length > 0) {
          setEmployees(savedEmployees);
        } else {
          setEmployees(MOCK_EMPLOYEES);
          await db.putAll(STORES.EMPLOYEES, MOCK_EMPLOYEES);
        }

        const finalWebhook = savedWebhook || cachedWebhook;
        const finalAutoSync = savedAutoSync !== null ? savedAutoSync : cachedAutoSync;

        if (finalWebhook) {
          setWebhookUrl(finalWebhook);
          webhookUrlRef.current = finalWebhook;
          localStorage.setItem(WEBHOOK_URL_KEY, finalWebhook);
        }
        
        setAutoSync(finalAutoSync);
        localStorage.setItem(AUTO_SYNC_KEY, String(finalAutoSync));
        
        setRecords(savedRecords.sort((a, b) => b.timestamp - a.timestamp));
        setIsInitializing(false);

        if (finalWebhook) {
           pullFromCloud(true);
        }
      } catch (e) {
        setIsInitializing(false);
      }
    };

    initData();
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      window.removeEventListener('focus', handleFocus);
    };
  }, [pullFromCloud]);

  const handleSaveRecord = async (recordData: Omit<ScrapRecord, 'id' | 'timestamp' | 'createdBy' | 'isLocked' | 'isSynced'>) => {
    const newRecord: ScrapRecord = {
      ...recordData,
      id: generateId(),
      timestamp: Date.now(),
      createdBy: CURRENT_USER,
      isLocked: false,
      isSynced: false,
    };
    
    await db.put(STORES.RECORDS, newRecord);
    setRecords(prev => [newRecord, ...prev]);
    
    if (autoSync && webhookUrl) {
        pushToCloud([newRecord]);
    }
  };

  const handleDeleteRecord = async (id: string) => {
    await db.delete(STORES.RECORDS, id);
    setRecords(prev => prev.filter(r => r.id !== id));
  };

  const handleUpdateWebhook = async (url: string) => {
    const cleanUrl = url.trim();
    setWebhookUrl(cleanUrl);
    webhookUrlRef.current = cleanUrl;
    await db.setSetting(WEBHOOK_URL_KEY, cleanUrl);
    localStorage.setItem(WEBHOOK_URL_KEY, cleanUrl);
    if (cleanUrl) pullFromCloud(false);
  };

  const pendingSyncCount = records.filter(r => !r.isSynced).length;

  if (isInitializing) {
    return (
      <div className="fixed inset-0 bg-emerald-700 flex flex-col items-center justify-center text-white p-6">
        <i className="fas fa-leaf text-6xl mb-4 animate-bounce"></i>
        <h1 className="text-2xl font-black mb-2 tracking-tighter">RUBBER TRACK</h1>
        <p className="opacity-70 text-xs font-bold uppercase tracking-[0.3em]">Đang khôi phục dữ liệu...</p>
      </div>
    );
  }

  const renderScreen = () => {
    switch (activeScreen) {
      case AppScreen.ENTRY:
        return <EntryScreen employees={employees} onSave={handleSaveRecord} isOnline={isOnline} />;
      case AppScreen.HISTORY:
        return <HistoryScreen records={records} onDelete={handleDeleteRecord} />;
      case AppScreen.SUMMARY:
        return <SummaryScreen records={records} />;
      case AppScreen.EMPLOYEES:
        return <EmployeeScreen 
          employees={employees} 
          onAdd={async (n, c) => {
            const e = {id: generateId(), name: n, code: c};
            await db.put(STORES.EMPLOYEES, e);
            setEmployees(p => [...p, e]);
          }} 
          onUpdate={async (id, n, c) => {
            const e = {id, name: n, code: c};
            await db.put(STORES.EMPLOYEES, e);
            setEmployees(p => p.map(emp => emp.id === id ? e : emp));
          }} 
          onDelete={async id => {
            await db.delete(STORES.EMPLOYEES, id);
            setEmployees(p => p.filter(e => e.id !== id));
          }} 
        />;
      case AppScreen.DOCS:
        return <DocsScreen />;
      case AppScreen.SYNC:
        return (
          <div className="flex flex-col h-full bg-gray-50 overflow-y-auto pb-20">
            <div className="p-8 text-center flex flex-col items-center justify-center space-y-4 bg-white border-b border-gray-100">
                <div className={`w-24 h-24 rounded-full flex items-center justify-center border-8 transition-colors ${pendingSyncCount > 0 ? 'border-orange-100 bg-orange-50' : 'border-emerald-100 bg-emerald-50'}`}>
                    {isSyncing ? <i className="fas fa-sync fa-spin text-3xl text-orange-500"></i> : <i className={`fas ${pendingSyncCount > 0 ? 'fa-cloud-arrow-up text-orange-500' : 'fa-cloud-check text-emerald-500'} text-3xl`}></i>}
                </div>
                <div className="space-y-1">
                  <h2 className="text-xl font-black text-gray-800">{pendingSyncCount > 0 ? `${pendingSyncCount} Bản ghi chưa gửi` : 'Đã đồng bộ với Google Drive'}</h2>
                  <p className="text-[10px] text-gray-400 uppercase font-bold tracking-widest">Link Drive là chìa khóa phục hồi dữ liệu</p>
                </div>
                
                <div className="w-full max-w-xs space-y-3 pt-4">
                  <button 
                    onClick={() => pushToCloud()} 
                    disabled={isSyncing || !isOnline} 
                    className={`w-full py-4 rounded-2xl font-black shadow-lg active:scale-95 text-xs uppercase tracking-widest transition-all ${!isOnline ? 'bg-gray-300 text-gray-500 shadow-none' : 'bg-emerald-600 text-white shadow-emerald-100'}`}
                  >
                    {isSyncing ? 'Đang gửi...' : 'Gửi lên Cloud ngay'}
                  </button>

                  <button 
                    onClick={() => pullFromCloud(false)} 
                    disabled={isSyncing || !isOnline} 
                    className={`w-full py-4 rounded-2xl font-black shadow-lg active:scale-95 text-xs uppercase tracking-widest transition-all ${!isOnline ? 'bg-gray-200 text-gray-400 shadow-none' : 'bg-blue-600 text-white shadow-blue-100'}`}
                  >
                    {isSyncing ? 'Đang tải...' : 'Khôi phục từ Cloud'}
                  </button>
                </div>
            </div>

            <div className="p-6 space-y-4">
                <div className="bg-white p-5 rounded-3xl border border-gray-100 shadow-sm flex items-center justify-between">
                    <div>
                        <div className="font-bold text-gray-800 text-sm">Tự động đồng bộ</div>
                        <div className="text-[10px] text-gray-400">Đảm bảo dữ liệu PC & iPhone luôn khớp</div>
                    </div>
                    <button 
                        onClick={() => { 
                          const newAuto = !autoSync;
                          setAutoSync(newAuto); 
                          db.setSetting(AUTO_SYNC_KEY, newAuto); 
                          localStorage.setItem(AUTO_SYNC_KEY, String(newAuto));
                        }}
                        className={`w-12 h-6 rounded-full transition-colors relative ${autoSync ? 'bg-emerald-500' : 'bg-gray-300'}`}
                    >
                        <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${autoSync ? 'left-7' : 'left-1'}`}></div>
                    </button>
                </div>

                <div className="space-y-3">
                    <h3 className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-2">Link Drive (Cực kỳ quan trọng)</h3>
                    <div className="bg-white p-4 rounded-3xl border border-gray-100 shadow-sm space-y-3">
                      <div className="flex items-center p-3 bg-gray-50 rounded-2xl">
                        <i className="fas fa-link text-emerald-500 mr-3"></i>
                        <input 
                          type="text" 
                          placeholder="Dán link Apps Script tại đây..."
                          className="bg-transparent border-0 outline-none w-full text-xs font-mono"
                          value={webhookUrl}
                          onChange={(e) => handleUpdateWebhook(e.target.value)}
                        />
                      </div>
                      <div className="p-3 bg-blue-50 rounded-2xl border border-blue-100">
                        <p className="text-[10px] text-blue-700 leading-relaxed">
                          <i className="fas fa-shield-alt mr-1"></i>
                          <b>Mẹo bảo mật:</b> Luôn lưu link này vào tin nhắn hoặc ghi chú. Nếu App bị reset, chỉ cần dán lại link này là mọi dữ liệu sẽ quay trở lại!
                        </p>
                      </div>
                    </div>
                </div>
            </div>
          </div>
        );
      default:
        return <EntryScreen employees={employees} onSave={handleSaveRecord} isOnline={isOnline} />;
    }
  };

  return (
    <Layout activeScreen={activeScreen} setScreen={setActiveScreen} pendingSyncCount={pendingSyncCount} isOnline={isOnline} isSyncing={isSyncing}>
      {renderScreen()}
    </Layout>
  );
};

export default App;
