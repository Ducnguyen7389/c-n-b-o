
import { Employee } from './types';

export const MOCK_EMPLOYEES: Employee[] = [
  { id: '1', code: 'NV001', name: 'Nguyễn Văn An' },
  { id: '2', code: 'NV002', name: 'Trần Thị Bình' },
  { id: '3', code: 'NV003', name: 'Lê Văn Cường' },
  { id: '4', code: 'NV004', name: 'Phạm Minh Đức' },
  { id: '5', code: 'NV005', name: 'Hoàng Thị Hoa' },
  { id: '6', code: 'NV006', name: 'Đặng Văn Giang' },
  { id: '7', code: 'NV007', name: 'Vũ Thị Hương' },
  { id: '8', code: 'NV008', name: 'Bùi Văn Hùng' },
  { id: '9', code: 'NV009', name: 'Ngô Thị Kim' },
  { id: '10', code: 'NV010', name: 'Lý Văn Long' },
  { id: '11', code: 'NV011', name: 'Trịnh Văn Nam' },
  { id: '12', code: 'NV012', name: 'Mai Thị Phương' },
  { id: '13', code: 'NV013', name: 'Phan Văn Quân' },
  { id: '14', code: 'NV014', name: 'Đỗ Thị Thu' },
  { id: '15', code: 'NV015', name: 'Tạ Văn Việt' },
];

export const CURRENT_USER = 'Quản lý Hiện trường A';
export const DEFAULT_UNIT = 'kg';
